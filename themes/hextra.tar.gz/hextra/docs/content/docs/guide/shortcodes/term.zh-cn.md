---
title: 术语
next: /docs/guide/deploy-site
---

一个用于显示术语定义的内置组件。

术语定义保存在结构化的 YAML [数据文件](/docs/advanced/additional-pages/#glossary)中，
每种支持的语言对应一个文件。

## 示例

* {{< term "静态网站生成器" >}}
* {{< term "SEO" >}}

## 用法

```
{{</* term "SEO" */>}}
```

如果术语在词汇表中未找到，则会原样返回该术语。

## 选项

| 名称         | 描述             |
|--------------|------------------|
| `entry`      | 术语名称         |

---
title: Glossary
layout: glossary
---

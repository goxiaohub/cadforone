module github.com/imfing/hextra

go 1.21
